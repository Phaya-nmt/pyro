n = gets.to_i

puts n.abs