n = gets.to_i

if n.even?
  puts "even"
else
  puts "odd"
end