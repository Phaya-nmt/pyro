cnt = 0
7.times do
  cnt += 1 if gets.chomp == "no"
end
puts cnt
