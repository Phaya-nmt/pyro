puts sprintf("%03d", gets.to_i)
