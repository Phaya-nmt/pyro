s, i = gets.split
i = i.to_i

puts s[i-1]