s = gets
t = gets

if s == t
  puts "Yes"
else
  puts "No"
end