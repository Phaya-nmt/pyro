ary = []

5.times do
  ary << gets.to_i
end

puts ary.max
puts ary.min