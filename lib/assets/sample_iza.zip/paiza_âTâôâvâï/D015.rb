n = gets.to_i

n.downto(1) do |i|
  puts i
end