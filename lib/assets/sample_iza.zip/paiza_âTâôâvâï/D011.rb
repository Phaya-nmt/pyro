s = gets.chomp

puts ("A".."Z").to_a.index(s) + 1