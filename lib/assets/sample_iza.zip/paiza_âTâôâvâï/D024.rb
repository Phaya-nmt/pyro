kaku = 180
2.times do
  kaku -= gets.to_i
end

puts kaku