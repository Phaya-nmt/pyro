a = gets.to_i
ans = 6 * a ** 2

puts ans