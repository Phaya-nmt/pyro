m, n = gets.split.map(&:to_i)

puts "#{m / n} #{m % n}"