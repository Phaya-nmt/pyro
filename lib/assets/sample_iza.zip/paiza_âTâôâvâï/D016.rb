s = gets
n = gets.to_i

puts s[0..n-1]