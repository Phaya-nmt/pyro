s = gets

puts s.upcase